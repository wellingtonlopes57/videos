<html>
    <head>
        <style>
            .sobre{
                
    width: 100%;
    height: 100%;
    margin: 0;
    position: absolute;
    background: #ff000000;
    z-index: 100;
}
            
        </style>
    </head>
<body>  
<div class="sobre">
    
</div>
<iframe   width="100%" height="100%" src="https://v3.sportzonline.to/channels/pt/sporttv4.php" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen=""></iframe>
</body>
</html>